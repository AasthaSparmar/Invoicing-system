#include<bits/stdc++.h>
using namespace std;
void solve(string s, string &f) {
	if (s.size()==0) {
		cout << f << " ";
		return;
	}
	//picking 
	string f1=f;
    string f2=f;
    f1.push_back(s[0]);
    s.erase(s.begin()+0);
	solve( s,  f1);
	solve( s,  f2);
}
int main() {
	string s = "abc";
	string f = "";
	cout<<"All possible subsequences are: "<<endl;
	solve(s, f);
}